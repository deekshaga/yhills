# Yhills_project_2
To find whether the person is vaccinated or not. h1n1_vaccine is the dependent variable-classification
